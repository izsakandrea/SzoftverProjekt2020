package Common;

import java.util.ArrayList;
import java.util.List;

import Model.Question;
import Model.User;

public class Common {
    public static String categoryId;
    public static User currentUser;
    public static List<Question> questionList = new ArrayList<>();
}
